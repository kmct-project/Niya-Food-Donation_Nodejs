
//////////COLLOCTIONS TO MONGODB////////////////
module.exports={
    USERS_COLLECTION:'users',
    ADMIN_COLLECTION:'admin',
    VOLUNTEER_COLLECTION: "volunteer",
    DONOR_COLLECTION: "donor",
    TRUSTS_COLLECTION: "trusts",
    FOODSPOT_COLLECTION: "foodspot",
    FCATEGORY_COLLECTION:'food-category'
}